<?php $__env->startSection('title', 'Quản lý cầu thủ'); ?>
<?php $__env->startSection('buttons'); ?>
    <a href="<?php echo e(route('players.create')); ?>" class="btn btn-success" data-toggle="modal"><span>Thêm cầu thủ mới</span></a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php if(@session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Tên cầu thủ</th>
                <th>Vị trí</th>
                <th>Số áo</th>
                <th>Ngày sinh</th>
                <th>Câu lạc bộ</th>
                <th class="text-center">Thao tác</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $player): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($player->name); ?></td>
                    <td><?php echo e($player->position); ?></td>
                    <td><?php echo e($player->number); ?></td>
                    <td><?php echo e($player->birthday); ?></td>
                    <td><?php echo e($player->club->name); ?></td>
                    <td class="d-flex gap-1">
                        <a href="<?php echo e(route('players.edit', $player->id)); ?>" class="btn btn-warning btn-sm d-flex align-items-center" id='deleteForm<?php echo e($player->id); ?>'>Sửa</a>
                        <button type="button" class="btn btn-danger btn-sm" data-bs-toggle="modal" data-bs-target="#playerDeleteModal<?php echo e($player->id); ?>">
                            Xóa
                        </button>
                        <a href="<?php echo e(route('players.show', $player->id)); ?>" class="btn btn-primary btn-sm text-white">Chi tiết</a>

                        <div class="modal fade" id="playerDeleteModal<?php echo e($player->id); ?>" tabindex="-1" aria-labelledby="playerDetailsModalLabel" aria-hidden="true">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="playerDeleteModalLabel">Xóa cầu thủ</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                    </div>
                                    <div class="modal-body">
                                        Bạn có chắc muốn xóa cầu thủ này?
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Hủy</button>
                                        <form action="<?php echo e(route('players.destroy', $player->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <div class="form-group">
                                                <button type="submit" class="btn btn-danger">Xác nhận</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('paginate'); ?>
<div class="mt-3 d-flex justify-content-center">
    <?php echo e($players->links('pagination::bootstrap-4')); ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cuoiky\CuoiKy\resources\views/players/index.blade.php ENDPATH**/ ?>